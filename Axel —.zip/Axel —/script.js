
function showPage(pageId) {
  const pages = document.querySelectorAll(".page");

  pages.forEach(function(page) {
    page.classList.remove("active");
  });

  const nextPage = document.getElementById(pageId);

  if (nextPage) {
    nextPage.classList.add("active");
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  }
}

function flipCard(card) {
  card.classList.toggle("flipped");
}

function openGift() {
  const box = document.getElementById("giftBox");
  const surprise = document.getElementById("surprise");
  const restart = document.getElementById("restart");

  if (!surprise.classList.contains("hidden")) {
    return;
  }

  box.classList.add("hidden");
  surprise.classList.remove("hidden");
  restart.classList.remove("hidden");

  createConfetti();

  setTimeout(function() {
    surprise.scrollIntoView({
      behavior: "smooth",
      block: "center"
    });
  }, 100);
}

function createConfetti() {
  const colors = [
    "#e6a7b8",
    "#d9c8f2",
    "#ffe39a",
    "#c4e4ef",
    "#f5c6d4"
  ];

  const symbols = ["♥", "✦", "✿", "★", "♡"];

  for (let i = 0; i < 55; i++) {
    const piece = document.createElement("span");

    piece.textContent =
      symbols[Math.floor(Math.random() * symbols.length)];

    piece.style.position = "fixed";
    piece.style.left = Math.random() * 100 + "vw";
    piece.style.top = "-25px";
    piece.style.zIndex = "9999";
    piece.style.pointerEvents = "none";
    piece.style.color =
      colors[Math.floor(Math.random() * colors.length)];
    piece.style.fontSize = (12 + Math.random() * 18) + "px";
    piece.style.transition =
      "transform 2.5s ease-in, opacity 2.5s ease-in";

    document.body.appendChild(piece);

    requestAnimationFrame(function() {
      piece.style.transform =
        "translateY(" + (window.innerHeight + 80) +
        "px) rotate(" + (Math.random() * 900 - 450) + "deg)";
      piece.style.opacity = "0";
    });

    setTimeout(function() {
      piece.remove();
    }, 2700);
  }
}

function restartSite() {
  document.getElementById("giftBox").classList.remove("hidden");
  document.getElementById("surprise").classList.add("hidden");
  document.getElementById("restart").classList.add("hidden");

  document.querySelectorAll(".reason-card").forEach(function(card) {
    card.classList.remove("flipped");
  });

  showPage("cover");
}
